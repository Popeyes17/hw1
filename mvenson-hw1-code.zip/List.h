#pragma once
#ifndef LIST_H
#define LIST_H

#include <algorithm>
using namespace std;

template <typename Object>
class List
{
private:
    // The basic doubly linked list node.
    // Nested inside of List, can be public
    // because the Node is itself private
    struct Node
    {
        Object  data;
        Node* prev;
        Node* next;

        Node(const Object& d = Object{ }, Node* p = nullptr, Node* n = nullptr)
            : data{ d }, prev{ p }, next{ n } { }

        Node(Object&& d, Node* p = nullptr, Node* n = nullptr)
            : data{ std::move(d) }, prev{ p }, next{ n } { }
    };

public:
    class const_iterator
    {
    public:

        // Public constructor for const_iterator.
        const_iterator() : current{ nullptr }
        { }

        // Return the object stored at the current position.
        // For const_iterator, this is an accessor with a
        // const reference return type.
        const Object& operator* () const
        {
            return retrieve();
        }

        const_iterator& operator++ ()
        {
            current = current->next;
            return *this;
        }

        const_iterator operator++ (int)
        {
            const_iterator old = *this;
            ++(*this);
            return old;
        }

        const_iterator& operator-- ()
        {
            current = current->prev;
            return *this;
        }

        const_iterator operator-- (int)
        {
            const_iterator old = *this;
            --(*this);
            return old;
        }

        bool operator== (const const_iterator& rhs) const
        {
            return current == rhs.current;
        }

        bool operator!= (const const_iterator& rhs) const
        {
            return !(*this == rhs);
        }

    protected:
        Node* current;

        // Protected helper in const_iterator that returns the object
        // stored at the current position. Can be called by all
        // three versions of operator* without any type conversions.
        Object& retrieve() const
        {
            return current->data;
        }
        // Protected constructor for const_iterator.
        // Expects a pointer that represents the current position.
        const_iterator(Node* p) : current{ p }
        { }

        friend class List<Object>;
    };

    class iterator : public const_iterator
    {
    public:

        // Public constructor for iterator.
        // Calls the base-class constructor.
        // Must be provided because the private constructor
        // is written; otherwise zero-parameter constructor
        // would be disabled.
        iterator()
        { }

        Object& operator* ()
        {
            return const_iterator::retrieve();
        }

        // Return the object stored at the current position.
        // For iterator, there is an accessor with a
        // const reference return type and a mutator with
        // a reference return type. The accessor is shown first.
        const Object& operator* () const
        {
            return const_iterator::operator*();
        }

        iterator& operator++ ()
        {
            this->current = this->current->next;
            return *this;
        }

        iterator operator++ (int)
        {
            iterator old = *this;
            ++(*this);
            return old;
        }

        iterator& operator-- ()
        {
            this->current = this->current->prev;
            return *this;
        }

        iterator operator-- (int)
        {
            iterator old = *this;
            --(*this);
            return old;
        }

    protected:
        // Protected constructor for iterator.
        // Expects the current position.
        iterator(Node* p) : const_iterator{ p }
        { }

        friend class List<Object>;
    };

public:
    List()
    {
        init();
    }

    ~List()
    {
        clear();
        delete head;
        delete tail;
    }



    /*      ONLY TOUCH CODE AFTER THIS LINE      */

    // Return mutable iterator representing beginning of list.
    iterator begin()
    {
        iterator begin;
        begin.current = head;
        begin.container = this;
        return begin;
        return iterator(nullptr);
    }

    // Return constant iterator representing beginning of list.
    const_iterator begin() const
    {
        return const_iterator(nullptr);
    }

    // Return iterator representing endmarker of list.
    // Mutator version is first, then accessor version.
    iterator end()
    {
        iterator end;
        end.current = nullptr;
        end.container = this;

        return end;
        return iterator(nullptr);
    }

    const_iterator end() const
    {
        return const_iterator(nullptr);
    }

    // Return number of elements currently in the list.
    int size() const
    {
        return -1;
    }

    // Return true if the list is empty, false otherwise.
    bool empty() const
    {
        return false;
    }

    // Removes all elements from the list
    void clear()
    {
        if (head == NULL || Object >= size || Object < 0)
        {
            return NULL;
        }
        else {
            Node* n;
            if (size == 1) // REMOVE THE ONLY NODE
            {
                n = head;
                head = NULL;
                tail = NULL;
                size--;

            }
            else if (Object == 0) //REMOVE THE FIRST NODE WHEN THERE'S MORE THAN ONE IN THE LIST
            {
                n = head;
                head = head->next;
                head->prev = NULL;
                size--;


            }
            else if (Object == size - 1) //REMOVE THE LAST WHEN THERE'S MORE THAN ONE NODE IN THE LIST
            {
                n = tail;
                tail = n->prev;
                tail->next = NULL;
                size--;

            }
            else
            {
                n = find_node(Object);
                n->prev->next = n->next;
                n->next->prev = n->prev;
                size--;
            }

            Node temp = n->item;
            delete n;
            return temp;
        }
    }

    /* front, back, push_front, push_back, pop_front, and pop_back
       are the basic double-ended queue operations. */


       //Returns the value stored in the first element of the list
    const Object& front() const
    {
        //note: these values need to be replaced, just here for compilation purposes
        return 0;
    }

    //Returns the value stored in the last element of the list
    const Object& back() const
    {
        //note: these values need to be replaced, just here for compilation purposes
        return 0;
    }

    //Inserts an object at the front of the list
    void push_front(const Object& x)
    {
        Object* temp = new Object(Node);
        if (head == nullptr)
        {
            head = temp;
            tail = temp;
        }
        else
        {
            temp->put(head);
            head = temp;
        }
        size++;
    }

    //Inserts an object at the back of the list
    void push_back(const Object& x)
    {
        Object* temp = new Object(Node);
        if (size() > 0)
        {
            tail->put(temp);
            tail = temp;
        }
        else
        {
            head = temp;
            tail = temp;
        }
      

    }

    //Removes the first element in the list
    void pop_front()
    {
        Node* temp = head;
        head = head->next;
        delete temp;
    }

    //Removes the last element in the list
    void pop_back()
    {
        if (head == nullptr) return;
        if (head->next == nullptr)
        {
            pop_front();
            return;
        }
        Node* temp = head;
        while (temp->next->next)
        {
            temp = temp->next;
        }
        delete temp->next;
        temp->next = nullptr;
    }

    // Insert x before itr.
    iterator insert(iterator itr, const Object& x)
    {
        if (itr.current == nullptr)
        {
            push_back(Object);
            return end();
        }

        // Node at insert position
        Node* moveAfter = itr.Object;
        // Node before insert position
        Node* nodeBefore = moveAfter->previous;

        // Create new node to be inserted
        Node* newNode = new Node(Object);

        // make new node's previous node the node before the node at insert position
        newNode->previous = nodeBefore;
        // makes new node's next node the node after the node at insert position
        newNode->next = moveAfter;
        moveAfter->previous = newNode;

        // if insert position is the position of first node of list, the new node is now the first node
        if (nodeBefore == nullptr)
        {
            head = newNode;
        }
        // if insert position is not the position of first node of list, next of node before node at insert position is set to newly inserted node
        else
        {
            nodeBefore->next = newNode;
        }

        // create iterator pointing to the new node
        iterator iterator_newNode = newNode;
        iterator_newNode.container = this;

        ++size;
        return iterator_newNode;
    }

    // Erase item at itr.
    iterator remove(iterator itr)
    {
        assert(Object.current != nullptr);

        // node to be deleted
        Node* removedNode = Object.current;
        // node before node to be deleted
        Node* nodeBefore = removedNode->previous;
        // node after node to be deleted
        Node* nodeAfter = removedNode->next;

        // if the node to be removed is the first node, set first to the node after the first node
        if (removedNode == nodeBefore)
        {
            head = nodeAfter;
        }
        // otherwise set next of node before the deleted node to the node after node to be deleted
        else
            nodeBefore->next = nodeAfter;

        // if the node to be removed is the last node, set first to the node before it
        if (removedNode == tail)
        {
            tail = nodeBefore;
        }
        // otherwise, set previous of node after to the node before the node to be removed
        else
        {
            nodeAfter->previous = nodeBefore;
        }

        delete removedNode;

        --size;

        // initialize iterator that will point to the node before the node to be removed
        iterator output;
        output.current = nodeAfter;
        output.container = this;

        return output;
        return itr;
    }

    // Return the index of the node containing the matching value
    // Return -1 if no matching value
    int find(const Object& x)
    {
        return -1;
    }

private:
    Node* head;
    Node* tail;

    void init()
    {
        unsigned int size;
        class iterator;
    }
};

#endif
